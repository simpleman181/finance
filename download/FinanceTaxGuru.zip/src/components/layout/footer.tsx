import Link from "next/link";
import { Separator } from "@/components/ui/separator";
import {
  Shield,
  Heart,
  Receipt,
  TrendingUp,
  Calculator,
  Mail,
  Phone,
  MapPin,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
} from "lucide-react";

const footerLinks = {
  termInsurance: {
    title: "Term Insurance",
    icon: Shield,
    color: "#1e40af",
    links: [
      { href: "/term-insurance", label: "Complete Guide" },
      { href: "/term-insurance/how-much-cover", label: "How Much Cover" },
      { href: "/term-insurance/best-plans", label: "Best Plans" },
      { href: "/term-insurance/for-salaried", label: "For Salaried" },
      { href: "/term-insurance/for-self-employed", label: "For Self Employed" },
      { href: "/term-insurance/riders", label: "Riders" },
      { href: "/term-insurance/claim-settlement-ratio", label: "Claim Ratio" },
      { href: "/term-insurance/premium-calculator", label: "Calculator" },
    ],
  },
  healthInsurance: {
    title: "Health Insurance",
    icon: Heart,
    color: "#dc2626",
    links: [
      { href: "/health-insurance", label: "Complete Guide" },
      { href: "/health-insurance/how-much-cover", label: "How Much Cover" },
      { href: "/health-insurance/best-plans", label: "Best Plans" },
      { href: "/health-insurance/individual-vs-family-floater", label: "Individual vs Family" },
      { href: "/health-insurance/for-parents-seniors", label: "For Seniors" },
      { href: "/health-insurance/waiting-period", label: "Waiting Period" },
      { href: "/health-insurance/claim-process", label: "Claim Process" },
      { href: "/health-insurance/premium-calculator", label: "Calculator" },
    ],
  },
  taxPlanning: {
    title: "Tax Planning",
    icon: Receipt,
    color: "#059669",
    links: [
      { href: "/tax", label: "Complete Tax Guide" },
      { href: "/tax/old-vs-new-regime", label: "Old vs New Regime" },
      { href: "/tax/income-tax-slabs", label: "Tax Slabs" },
      { href: "/tax/section-80c", label: "Section 80C" },
      { href: "/tax/section-80d", label: "Section 80D" },
      { href: "/tax/capital-gains-shares", label: "Capital Gains" },
      { href: "/tax/mutual-funds-taxation", label: "Mutual Funds Tax" },
      { href: "/tax/income-tax-calculator", label: "Tax Calculator" },
    ],
  },
  investments: {
    title: "Investments",
    icon: TrendingUp,
    color: "#7c3aed",
    links: [
      { href: "/investing", label: "Personal Finance" },
      { href: "/investing/what-is-sip", label: "What is SIP" },
      { href: "/investing/sip-vs-lumpsum", label: "SIP vs Lump Sum" },
      { href: "/investing/best-mutual-funds-beginners", label: "Best Mutual Funds" },
      { href: "/investing/emergency-fund", label: "Emergency Fund" },
      { href: "/investing/retirement-planning", label: "Retirement Planning" },
      { href: "/investing/retirement-calculator", label: "Retirement Calculator" },
      { href: "/investing/common-mistakes", label: "Common Mistakes" },
    ],
  },
  tools: {
    title: "Tools & Calculators",
    icon: Calculator,
    color: "#ea580c",
    links: [
      { href: "/tools/compare-term-insurance", label: "Compare Term Insurance" },
      { href: "/tools/compare-health-insurance", label: "Compare Health Insurance" },
      { href: "/tools/term-coverage-calculator", label: "Term Coverage Calculator" },
      { href: "/tools/health-coverage-estimator", label: "Health Coverage Estimator" },
      { href: "/tools/sip-return-calculator", label: "SIP Return Calculator" },
      { href: "/tools/emi-calculator", label: "EMI Calculator" },
      { href: "/tools/tax-saving-planner", label: "Tax Saving Planner" },
      { href: "/tools/financial-health-check", label: "Financial Health Check" },
    ],
  },
};

const socialLinks = [
  { icon: Facebook, href: "#", label: "Facebook" },
  { icon: Twitter, href: "#", label: "Twitter" },
  { icon: Linkedin, href: "#", label: "LinkedIn" },
  { icon: Instagram, href: "#", label: "Instagram" },
];

export function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300">
      {/* Main Footer */}
      <div className="container px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-2 space-y-4">
            <Link href="/" className="flex items-center space-x-2">
              <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-[#1e40af] to-[#059669]">
                <span className="text-white font-bold text-lg">F</span>
              </div>
              <span className="font-bold text-xl">
                <span className="text-blue-400">Finance</span>
                <span className="text-emerald-400">Tax</span>
                <span className="text-orange-400">Pro</span>
              </span>
            </Link>
            <p className="text-sm text-slate-400 max-w-xs">
              Your trusted companion for all finance, insurance, and tax planning needs in India. 
              Make informed decisions with our comprehensive guides and tools.
            </p>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Mail className="h-4 w-4 text-[#1e40af]" />
                <span>support@financetaxpro.com</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Phone className="h-4 w-4 text-[#059669]" />
                <span>+91 1800-XXX-XXXX</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="h-4 w-4 text-[#ea580c]" />
                <span>Mumbai, Maharashtra, India</span>
              </div>
            </div>
          </div>

          {/* Link Sections */}
          {Object.values(footerLinks).map((section) => {
            const Icon = section.icon;
            return (
              <div key={section.title} className="space-y-4">
                <div className="flex items-center gap-2 font-semibold text-white">
                  <Icon className="h-4 w-4" style={{ color: section.color }} />
                  {section.title}
                </div>
                <ul className="space-y-2">
                  {section.links.map((link) => (
                    <li key={link.href}>
                      <Link
                        href={link.href}
                        className="text-sm text-slate-400 hover:text-white transition-colors"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>

      <Separator className="bg-slate-800" />

      {/* Bottom Footer */}
      <div className="container px-4 md:px-6 py-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-slate-400">
            © {new Date().getFullYear()} FinanceTaxPro. All rights reserved.
          </p>
          
          <div className="flex items-center gap-4">
            {socialLinks.map((social) => {
              const Icon = social.icon;
              return (
                <Link
                  key={social.label}
                  href={social.href}
                  className="text-slate-400 hover:text-white transition-colors"
                  aria-label={social.label}
                >
                  <Icon className="h-5 w-5" />
                </Link>
              );
            })}
          </div>

          <div className="flex items-center gap-4 text-sm text-slate-400">
            <Link href="#" className="hover:text-white transition-colors">
              Privacy Policy
            </Link>
            <Link href="#" className="hover:text-white transition-colors">
              Terms of Service
            </Link>
            <Link href="#" className="hover:text-white transition-colors">
              Disclaimer
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
