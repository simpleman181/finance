import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Analytics } from "@vercel/analytics/react";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://financetaxpro.in"),
  title: {
    default: "FinanceTaxPro - Your Complete Guide to Finance, Insurance & Tax in India",
    template: "%s | FinanceTaxPro"
  },
  description: "Comprehensive educational guide to term insurance, health insurance, income tax planning, and investments in India. Free calculators, expert guides, and unbiased comparisons. No sales, just knowledge.",
  keywords: ["term insurance", "health insurance", "income tax", "tax planning", "investments", "mutual funds", "SIP", "insurance guide", "tax calculator", "India finance"],
  authors: [{ name: "FinanceTaxPro Team", url: "https://financetaxpro.in" }],
  creator: "FinanceTaxPro",
  publisher: "FinanceTaxPro",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  icons: {
    icon: "/favicon.ico",
    apple: "/apple-touch-icon.png",
  },
  manifest: "/manifest.json",
  openGraph: {
    type: "website",
    locale: "en_IN",
    url: "https://financetaxpro.in",
    siteName: "FinanceTaxPro",
    title: "FinanceTaxPro - Complete Guide to Finance, Insurance & Tax",
    description: "Your one-stop destination for insurance, tax planning, and investment guidance in India. Educational content only.",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "FinanceTaxPro - Financial Education Platform for India",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "FinanceTaxPro",
    description: "Complete guide to finance, insurance & tax in India",
    images: ["/og-image.png"],
    creator: "@financetaxpro",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    google: "your-google-verification-code",
  },
  alternates: {
    canonical: "https://financetaxpro.in",
  },
  category: "finance",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Preconnect to improve performance */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        
        {/* Skip link for accessibility */}
        <a href="#main-content" className="skip-link">
          Skip to main content
        </a>
      </head>
      <body className={`${inter.variable} font-sans antialiased bg-background text-foreground min-h-screen flex flex-col`}>
        <Header />
        <main id="main-content" className="flex-1">
          {children}
        </main>
        <Footer />
        <Toaster />
        <Analytics />
      </body>
    </html>
  );
}
